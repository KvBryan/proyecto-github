(function($) {

	$(function() {

		new FLBuilderContactForm({
			id: '<?php echo $id; ?>'
		});
	});

})(jQuery);
