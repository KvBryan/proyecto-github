<?php

if ( class_exists( 'FLUpdater' ) ) {
	FLUpdater::add_product(array(
		'name'    => 'Beaver Builder Plugin (Agency Version)',
		'version' => '2.8.0.6',
		'slug'    => 'bb-plugin',
		'type'    => 'plugin',
	));
}
