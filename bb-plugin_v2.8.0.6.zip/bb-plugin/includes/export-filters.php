<div class="export-filters" id="fl-builder-template-filters">
	<select id="fl-builder-template-export-select" name="fl-builder-template-export-select">
		<option value="all"><?php _e( 'Export All', 'fl-builder' ); ?></option>
		<option value="selected"><?php _e( 'Export Selected', 'fl-builder' ); ?></option>
	</select>
	<span class="spinner"></span>
	<div id="fl-builder-template-export-posts"></div>
</div>
